"""Make original synthetic footage and speech, without a paid or remote model API."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import wave

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from kokoro_onnx import Kokoro

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'demo' / 'source'
CHAPTERS = [
    ('Start with one workflow', [
        'A useful product begins with one repeated problem, such as checking a supplier spreadsheet before a store imports it.',
        'Describe the input, the decision, and the finished result before you spend time building a large collection of features.'
    ]),
    ('Find the expensive mistake', [
        'Look for the mistake that costs the buyer time, such as a missing product code or two rows that describe the same item.',
        'Show the exact row and a clear explanation, so the buyer can check the evidence instead of trusting a mysterious score.'
    ]),
    ('Keep a small first version', [
        'A small first version can run locally with a sample file, a visible result, and an export the buyer can actually use.',
        'A working example with honest limitations is easier to evaluate than a long promise about features that do not exist yet.'
    ]),
    ('Price the agreed outcome', [
        'Agree on the file size, the output format, and the acceptance example before quoting a fixed price for a first delivery.',
        'A pending proposal is not revenue, and a platform reward is not cash in your bank account until withdrawal is confirmed.'
    ]),
    ('Make revisions precise', [
        'When the buyer asks for one correction, record the requested change and preserve the parts of the delivery they already approved.',
        'Compare the unchanged files before and after the revision, so a small correction does not quietly replace the whole project.'
    ]),
    ('Earn repeat work through evidence', [
        'A clear report explains what was checked, what failed, and which assumptions still require confirmation from the person using the result.',
        'Repeat work comes from useful outcomes and clear communication, while the final earning amount always depends on real customer decisions.'
    ])
]


def main():
    if DEST.exists():
        raise SystemExit('Source exists; preserving the completed fixture.')
    DEST.mkdir(parents=True)
    model = Kokoro(str(ROOT / '.models/kokoro-v1.0.int8.onnx'),
                   str(ROOT / '.models/voices-v1.0.bin'))
    rate, segments, entries, cursor = 24000, [], [], 0
    font = ImageFont.load_default(size=52)
    small = ImageFont.load_default(size=28)
    for i, (title, sentences) in enumerate(CHAPTERS, 1):
        image = Image.new('RGB', (1280, 720), '#101c2d')
        draw = ImageDraw.Draw(image)
        draw.rounded_rectangle((78, 80, 1202, 640), radius=32, fill='#172c43', outline='#294860', width=2)
        draw.text((124, 112), 'THE USEFUL LAUNCH', fill='#6adbc8', font=small)
        draw.text((124, 218), '%02d' % i, fill='#6adbc8', font=ImageFont.load_default(size=92))
        draw.text((124, 354), title, fill='white', font=font)
        draw.text((124, 550), 'Original synthetic demo • Local speech • No customer footage', fill='#a6bed4', font=small)
        image.save(DEST / ('chapter-%02d.png' % i))
        chapter_start = cursor / rate
        for text in sentences:
            audio, actual_rate = model.create(text, voice='af_heart', speed=1.0, lang='en-us')
            if actual_rate != rate:
                raise RuntimeError('Unexpected sample rate')
            silence = np.zeros(int(rate * 0.45), dtype=np.float32)
            segments.extend([silence, audio, silence])
            entries.append({'start': (cursor + len(silence)) / rate,
                            'end': (cursor + len(silence) + len(audio)) / rate,
                            'text': text, 'chapter': i})
            cursor += 2 * len(silence) + len(audio)
        entries[-1]['chapter_end'] = cursor / rate
        print(json.dumps({'chapter': i, 'end_seconds': round(cursor / rate, 2)}), flush=True)
    joined = np.concatenate(segments)
    with wave.open(str(DEST / 'narration.wav'), 'wb') as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(rate)
        output.writeframes((np.clip(joined, -1, 1) * 32767).astype('<i2').tobytes())
    timeline = ['ffconcat version 1.0']
    start = 0
    for i in range(1, len(CHAPTERS) + 1):
        end = next(e['chapter_end'] for e in entries if e['chapter'] == i and 'chapter_end' in e)
        timeline += ["file 'chapter-%02d.png'" % i, 'duration %.6f' % (end - start)]
        start = end
    timeline.append("file 'chapter-06.png'")
    (DEST / 'source.ffconcat').write_text('\n'.join(timeline) + '\n')
    subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error', '-n',
                    '-f', 'concat', '-safe', '1', '-i', str(DEST / 'source.ffconcat'),
                    '-i', str(DEST / 'narration.wav'), '-t', '%.6f' % (cursor / rate),
                    '-r', '30', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20',
                    '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '128k',
                    '-movflags', '+faststart', str(DEST / 'original-demo.mp4')], check=True)
    video = DEST / 'original-demo.mp4'
    value = {'source_sha256': hashlib.sha256(video.read_bytes()).hexdigest(),
             'synthetic': True, 'voice': 'Kokoro v1.0 af_heart, synthetic, Apache-2.0 model',
             'duration': cursor / rate, 'sentences': entries}
    (DEST / 'reference.json').write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps({'ok': True, 'duration': cursor / rate, 'bytes': video.stat().st_size}))


if __name__ == '__main__':
    main()
