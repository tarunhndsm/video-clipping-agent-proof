# Video clipping delivery

Source SHA256: 8e480fbb101c62828715378674b4632ef55e638e96b604f5e60bc7f37f7dad16
Selection: content_analysis_heuristic
Retention provenance: None supplied; transcript content analysis used.

This tool uses transcript terms and any supplied retention data. It does not predict virality. Speech recognition may need correction; review the included transcript and play the clips before publishing.

Fit layout preserves the full frame with padding. Center crop is opt-in and does not track speakers or faces.

## clip-01
Source 15.920–39.250 seconds.
No replay/retention data was supplied. Content analysis uses transcript terms; complete passage includes "actually", "check", "code", "costs". Topic keyword occurrences: 5.

Look for the mistake that costs the buyer time, such as a missing product code or two rows that describe the same item. Show the exact row and a clear explanation, so the buyer can check the evidence instead of trusting a mysterious score. A small first version can run locally with a sample file, a visible result, and an export the buyer can actually use.

- vertical: clip-01-vertical.mp4 (720×1280), SHA256 bc723d1924b87e614b0af5fdc7476944f1d220376426c10872ed6f828fb1261a
- square: clip-01-square.mp4 (720×720), SHA256 e4f4e91e7c05aa334035406a07bc63c099d328863c951cd704e6084e50fb7b45
- landscape: clip-01-landscape.mp4 (1280×720), SHA256 8360ce1881d41d6b41719ca4abbedf9943aafc9547b5cd83435f651f750d5a5e

## clip-02
Source 56.270–72.170 seconds.
No replay/retention data was supplied. Content analysis uses transcript terms; complete passage includes "account", "already", "approved", "asks". Topic keyword occurrences: 1.

A pending proposal is not revenue, and a platform reward is not cash in your bank account until withdrawal is confirmed. When the buyer asks for one correction, record the requested change and preserve the parts of the delivery they already approved.

- vertical: clip-02-vertical.mp4 (720×1280), SHA256 771458ba23aba1df46946b11bdb6f9dfadfab72e3d90821f2573f1a254b6565e
- square: clip-02-square.mp4 (720×720), SHA256 26ce0c1b17ebe0fe7024c31d40e7bada954bdbcf821e9ba24f69228d6a3170b6
- landscape: clip-02-landscape.mp4 (1280×720), SHA256 aeb97b39939c19e92aa5f8e4bbf8577768847a196ef48d888fd5459a09b8f870

## clip-03
Source 80.620–98.710 seconds.
No replay/retention data was supplied. Content analysis uses transcript terms; complete passage includes "always", "amount", "assumptions", "checked". Topic keyword occurrences: 1.

A clear report explains what was checked, what failed, and which assumptions still require confirmation from the person using the result. Repeat work comes from useful outcomes and clear communication, while the final earning amount always depends on real customer decisions.

- vertical: clip-03-vertical.mp4 (720×1280), SHA256 04482356ae775e09850341a9e2795310103efc972a962f1451f8f2c49d5ebf4e
- square: clip-03-square.mp4 (720×720), SHA256 1e7d0f3e2c87a184141a89e6b1be136bbc376ed9b496ee6469e3445fc1e61729
- landscape: clip-03-landscape.mp4 (1280×720), SHA256 2c743f0068ef89bc5de8f9aac647796a6e071db21d58ce54a298d7e041d0926a

