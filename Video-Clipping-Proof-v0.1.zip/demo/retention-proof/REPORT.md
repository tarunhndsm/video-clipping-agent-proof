# Video clipping delivery

Source SHA256: 8e480fbb101c62828715378674b4632ef55e638e96b604f5e60bc7f37f7dad16
Selection: retention
Retention provenance: Synthetic test intervals for branch verification; these are not real audience analytics.

This tool uses transcript terms and any supplied retention data. It does not predict virality. Speech recognition may need correction; review the included transcript and play the clips before publishing.

Fit layout preserves the full frame with padding. Center crop is opt-in and does not track speakers or faces.

## clip-01
Source 48.400–64.190 seconds.
Overlaps supplied replay/retention data with peak 0.990; complete passage includes "acceptance", "account", "agree", "bank".

Agree on the file size, the output format, and the acceptance example before quoting a fixed price for a first delivery. A pending proposal is not revenue, and a platform reward is not cash in your bank account until withdrawal is confirmed.

- vertical: clip-01-vertical.mp4 (720×1280), SHA256 f52763674382ce5c491f2cd60433c6d9ec6b901deb39fc7e574511688416ec6e

