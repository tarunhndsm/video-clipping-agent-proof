"""Independent checks against the known script, decoded media and prior files."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json
import re
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from agent import create, read_json, revise
from media import command, digest, probe
from selection import sentences


def tokens(text):
    return re.findall(r"[a-z]+(?:'[a-z]+)?", text.lower())


def word_error_count(expected, actual):
    row = list(range(len(actual) + 1))
    for i, word in enumerate(expected, 1):
        following = [i]
        for j, other in enumerate(actual, 1):
            following.append(min(following[-1] + 1, row[j] + 1,
                                 row[j - 1] + (word != other)))
        row = following
    return row[-1]


def main():
    started = time.monotonic()
    demo = ROOT / 'demo'
    source = demo / 'source/original-demo.mp4'
    reference = read_json(demo / 'source/reference.json')
    final = read_json(demo / 'delivery-final/manifest.json')
    revision = read_json(demo / 'revision-final/manifest.json')
    retention = read_json(demo / 'retention-proof/manifest.json')
    checks, details = {}, {}
    checks['source_unchanged'] = digest(source) == reference['source_sha256']
    checks['exact_count_and_all_formats'] = (len(final['clips']) == 3 and
        all({a['format'] for a in c['assets']} == {'vertical', 'square', 'landscape'} for c in final['clips']))
    truth = tokens(' '.join(s['text'] for s in reference['sentences']))
    speech = read_json(demo / 'transcript-final.json')
    actual = tokens(' '.join(w['text'] for w in speech['words']))
    details['full_transcript'] = {'reference_words': len(truth),
        'word_errors': word_error_count(truth, actual),
        'note': "Raw recognition uses supplier's in place of supplier. Selected clips are checked separately."}
    clip_results = []
    for clip in final['clips']:
        target = tokens(clip['text'])
        match = None
        for i in range(len(reference['sentences'])):
            for j in range(i + 1, len(reference['sentences']) + 1):
                passage = tokens(' '.join(s['text'] for s in reference['sentences'][i:j]))
                if passage == target:
                    match = (i, j)
        complete_audio = bool(match and
            clip['start'] <= reference['sentences'][match[0]]['start'] and
            clip['end'] >= reference['sentences'][match[1] - 1]['end'])
        clip_results.append({'id': clip['id'], 'exact_script_match': match is not None,
                             'contains_entire_synthesized_sentence_audio': complete_audio,
                             'start': clip['start'], 'end': clip['end']})
    details['selected_clips'] = clip_results
    checks['selected_captions_match_known_script'] = all(c['exact_script_match'] for c in clip_results)
    checks['boundaries_include_whole_known_sentences'] = all(c['contains_entire_synthesized_sentence_audio'] for c in clip_results)
    def decode(asset):
        path = demo / 'delivery-final' / asset['file']
        measured = probe(path)
        command(['ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error',
                 '-i', str(path), '-f', 'null', '-'], timeout=120)
        return (digest(path) == asset['sha256'] and measured['audio'] and
                measured['video_codec'] == 'h264' and
                measured['width'] == asset['width'] and measured['height'] == asset['height'] and
                path.with_suffix('.srt').is_file())
    assets = [a for c in final['clips'] for a in c['assets']]
    with ThreadPoolExecutor(max_workers=2) as pool:
        checks['nine_media_files_fully_decode_and_match_manifest'] = all(pool.map(decode, assets))
    unchanged = revision['revision']['unchanged_files']
    checks['only_requested_clip_revised'] = revision['revision']['changed_clip_ids'] == ['clip-02']
    checks['unrequested_media_and_captions_byte_identical'] = bool(unchanged) and all(
        digest(demo / 'delivery-final' / name) == sha == digest(demo / 'revision-final' / name)
        for name, sha in unchanged.items())
    details['unchanged_revision_files'] = len(unchanged)
    checks['retention_branch_uses_supplied_peak'] = all(
        c['selection_mode'] == 'retention' and c['start'] < 54.5 and c['end'] > 49.5 and
        c['retention_peak'] == .99 for c in retention['clips'])
    checks['synthetic_retention_is_labelled'] = 'not real audience analytics' in retention['retention_provenance']
    repeat = create(source, read_json(demo / 'brief.json'), demo / 'delivery-final',
                    transcript=demo / 'transcript-final.json')
    checks['exact_create_retry_is_no_op'] = repeat.get('_no_op') is True
    repeat_revision = revise(source, demo / 'delivery-final', read_json(demo / 'revision.json'),
                             demo / 'revision-final')
    checks['exact_revision_retry_is_no_op'] = repeat_revision.get('_no_op') is True
    result = {'synthetic_fixture_only': True, 'checks': checks, 'details': details,
              'passed': sum(checks.values()), 'total': len(checks),
              'validation_seconds': round(time.monotonic() - started, 3),
              'limitations': ['No customer acceptance or production reliability is established.',
                              'Public YouTube ingestion has not been exercised in this fixture.',
                              'Synthetic retention is not evidence of audience performance.']}
    (ROOT / 'VERIFICATION.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
